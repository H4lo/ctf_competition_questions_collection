/**
 * @file idaplugin/idaplugin.h
 * @brief Main idaplugin header.
 * @copyright (c) 2017 Avast Software, licensed under the MIT license
 */

#ifndef IDAPLUGIN_IDAPLUGIN_H
#define IDAPLUGIN_IDAPLUGIN_H

#include "defs.h"

namespace idaplugin {

void runSelectiveDecompilation(func_t *fnc2decomp = nullptr, bool force = false);

} // namespace idaplugin

#endif
