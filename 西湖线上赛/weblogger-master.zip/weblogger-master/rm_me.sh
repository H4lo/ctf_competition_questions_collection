pdir=`pwd`
rm -r $pdir

